import React from 'react'
import Sidebar from '../../components/Sidebar'

const EmployerProfile = () => {
  return (
    <>
      <Sidebar role="employer" />
      {/* Add your EmployerProfile component content here */}
    </>
  )
}

export default EmployerProfile